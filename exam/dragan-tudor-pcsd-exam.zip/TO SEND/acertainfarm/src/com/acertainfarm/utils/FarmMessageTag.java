package com.acertainfarm.utils;

/**
 * Created by tudorgk on 18/1/15.
 */
public enum FarmMessageTag {
    NEWMEASUREMENT, UPDATE, QUERY;
}
